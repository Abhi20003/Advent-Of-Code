# -*- coding: utf-8 -*-
"""
Created on Tue Dec  7 12:03:12 2021

@author: 91971
"""


f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D7.txt"

file=open(f1,'r')
lines=file.read()
lf=[int(i) for i in lines.split(',')]
def Median(lf):
    lf.sort()
    if len(lf)%2==0:
        median=(lf[int(len(lf)/2)]+lf[int((len(lf)/2))-1])/2
    else:
        median=lf[int((len(lf)-1)/2)]
    return int(median)

def MedianDeviation(l,median):
    medianlist=[abs(i-median) for i in l]
    #MedianDeviation = Median(medianlist)
    fuel = sum(medianlist)
    return fuel

answer = MedianDeviation(lf,Median(lf))
print(answer)

def Mean(lf):
    mean=round((sum(lf)/len(lf)),0)
    return int(mean)

def MeanDeviation(l,mean):
    fuel=100000000000000000000
    for j in range (mean-1,mean+2):
        meanlist=[abs(i-j) for i in l]
        fuellist=[int((k*(k+1))/2) for k in meanlist]
        if fuel>sum(fuellist):
            fuel=sum(fuellist)
        else:
            continue
    return fuel
    
a = MeanDeviation(lf,Mean(lf))
print(a)