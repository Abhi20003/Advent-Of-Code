# -*- coding: utf-8 -*-
"""
Created on Mon Dec  6 11:30:46 2021

@author: 91971
"""


f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D6.txt"

file=open(f1,'r')
lines=file.read()
#lf=[int(i) for i in lines]


dict1={ 
       0:lines.count('0'),
       1:lines.count('1'),
       2:lines.count('2'),
       3:lines.count('3'),
       4:lines.count('4'),
       5:lines.count('5'),
       6:lines.count('6'),
       7:lines.count('7'),
       8:lines.count('8')
       }

    

def lanternfish(lf,days):
    c=0
    while c!=days:  
        for i in range(0,len(lf)):
            if i%100000==0:
                print(i)
            if lf[i]!=0:
                lf[i]-=1
            else:
                lf[i]=6
                lf.append(8)
        c+=1
            
    return len(lf)

def lanternfish2(dict1,days):
    for i in range(days):
        dict1={ 
               0:dict1[1],
               1:dict1[2],
               2:dict1[3],
               3:dict1[4],
               4:dict1[5],
               5:dict1[6],
               6:dict1[7]+dict1[0],
               7:dict1[8],
               8:dict1[0]
               }
    return sum(dict1.values())
print(lanternfish2(dict1,256))
    
        