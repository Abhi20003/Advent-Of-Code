# -*- coding: utf-8 -*-
"""
Created on Wed Dec  8 11:23:16 2021

@author: 91971
"""


f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D8.txt"

file=open(f1,'r')
lines=file.readlines()

d1={
   0:6,
   1:2,
   2:5,
   3:5,
   4:4,
   5:5,
   6:6,
   7:3,
   8:7, 
   9:6
   }

def Partone(lines):
    c=0
    for i in lines:
        l1=i[:-1].split(" ")
        for j in range(11,15):
            if len(l1[j]) in [2,3,4,7]:
                c+=1
            else:
                continue
    return c
            
                
#print(Partone(lines))

def Common(lines):
    a=[i for i in lines[0]]
    for i in range(0,len(lines)):
        a=[j for j in a if j in lines[i]]
    return a
        
def Getkey(d,value):
    for i in d.keys():
        if d[i]==value:
            return str(i)
        else:
            continue
    



def Parttwo(lines):
    final=[]
    for i in lines:
        l1=i[:-1].split(" ")
        d={}
        for j in range(0,10):
            if len(l1[j])==2:
                d[1]=list(l1[j])
            elif len(l1[j])==3:
                d[7]=list(l1[j])
            elif len(l1[j])==4:
                d[4]=list(l1[j])
            elif len(l1[j])==7:
                d[8]=list(l1[j])
        top=[i for i in d[7] if i not in d[1]]  
        z=[]
        y=[]
        for k in range(0,10):
            if len(l1[k])==6:
                z.append(l1[k])
            elif len(l1[k])==5:
                y.append(l1[k])
        z1=[list(i) for i in z]
        for t in z1:
            t.sort()
        a=Common(z)
        #print(z)
        #print(a)
        b=Common(y)
        #print(b)
        ab1=[i for i in a if i in b]
        bottom=[i for i in ab1 if i not in top]
        middle=[i for i in b if i not in top if i not in bottom]
        lu=[i for i in d[4] if i not in d[1] if i not in middle]
        ld=[i for i in d[8] if i not in d[4] if i not in top if i not in bottom]
        d[0]=[i for i in d[8] if i not in middle]
        d[9]=[i for i in d[8] if i not in ld]
        d[3]=[i for i in d[9] if i not in lu]
        d[9].sort()
        d[0].sort()
        d[6]=[i for i in z1 if i!=d[9] if i!=d[0]][0]
        ru=[i for i in ['a','b','c','d','e','f','g'] if i not in d[6]]
        rd=[i for i in d[6] if i not in top if i not in bottom if i not in middle if i not in lu if i not in ld]
        d[2]=[i for i in d[8] if i not in rd if i not in lu]
        d[5]=[i for i in d[8] if i not in ru if i not in ld]
        #print(rd,lu,ru,ld,top,bottom,middle)
        #print(d)
        u=11
        
        digit=''
        while u<15:
            #print('yup')
            for m in d.values():
                m.sort()
                s=list(l1[u])
                s.sort()
                #print(m,s,u)
                if m==s:
                    #print('yup')
                    digit+=Getkey(d,m)
                    u+=1    
                    break
        #print(int(digit))
        final.append(int(digit))
    return final

                 
print(sum(Parttwo(lines)))        



                

    
        
        
        
        
        