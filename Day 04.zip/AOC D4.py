# -*- coding: utf-8 -*-
"""
Created on Sat Dec  4 11:57:56 2021

@author: 91971
"""
import copy

f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D4.txt"

file=open(f1,'r')
lines=file.readlines()
trials = list(lines[0][:-1].split(','))
#print(trials)

L=[]

for i in lines[1:]:
    a=i.replace("  "," ").strip()
    l=a.split(" ")
    if len(l)==5:
        L.append(l)

def divide_list(l, n):
    for i in range(0, len(l), n): 
        yield l[i:i + n]
        
final=list(divide_list(L,5))
final2=copy.deepcopy(final)

def summation(j):
    sum1=0
    for k in j:
        for l in k:
            if l!='#':
                sum1+=int(l)
    return sum1
            
def func(j):
    notstop=True
    c1=0
    while notstop:
        for k in trials:
            c1+=1
            if notstop==False:
                break
            row=-1
            for l in j:
                if notstop==False:
                    break
                row+=1
                col=-1
                for m in l:
                    if notstop==False:
                        break
                    col+=1
                    if m==k:
                        j[row][col]='#'
                        #c1+=1
                    if l==['#','#','#','#','#']:
                        notstop=False
                        last=k
                        break
                    if notstop:
                        for n in range(0,5):
                            for p in j:
                                if p[n]=='#':
                                    continue
                                else:
                                    break
                            else:
                                last=k
                                notstop=False
                    else:
                        continue
        print(j)
        print(c1)
        sum1=summation(j)
        return(c1,last,sum1)
    
#for j in final:
#    func(j)

n2=0
T=[]
for j in final:
    T.append(func(j))
for o in T:
    n1=o[0]
    if n1>n2:
        n2=n1
for q in T:
    if q[0]==n2:
        last=int(q[1])
        sum1=q[2]
print(sum1)
print(last)
print(sum1*last)




'''n2=100
T=[]
for j in final:
    T.append(func(j))
for o in T:
    n1=o[0]
    if n1<n2:
        n2=n1
for q in T:
    if q[0]==n2:
        last=int(q[1])
        sum1=q[2]
print(sum1)
print(last)
print(sum1*last)
        '''