# -*- coding: utf-8 -*-
"""
Created on Fri Dec  3 12:23:39 2021

@author: 91971
"""

import copy
f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D3.txt"

file=open(f1,'r')
lines=file.readlines()

def mostcommon(lines):
    a=''
    for j in range (0,12):
        c1=0
        c0=0
        for i in lines:
            if i[j]=='1':
                c1+=1
            elif i[j]=='0':
                c0+=1
        if c1>c0:
            a+='1'
        else:
            a+='0'
    return int(a,2)

def leastcommon(lines):
    a=''
    for j in range (0,12):
        c1=0
        c0=0
        for i in lines:
            if i[j]=='1':
                c1+=1
            elif i[j]=='0':
                c0+=1
        if c1<c0:
            a+='1'
        elif c1>c0:
            a+='0'

    return int(a,2)

gamma=mostcommon(lines)
epsilon=leastcommon(lines)
print(gamma*epsilon)

def CO2rating(lines):
    l=copy.deepcopy(lines)
    for j in range (0,12):
        c1=0
        c0=0
        for i in l:
            if i[j]=='1':
                c1+=1
            elif i[j]=='0':
                c0+=1
        if c1<c0:
            for b in lines:
                #print(l)
                if b[j]=='0' and len(l)>2 and b in l:
                        l.remove(b)
        elif c1>c0:
            for b in lines:
                #print(l)
                if b[j]=='1' and len(l)>2 and b in l:
                    l.remove(b)
        else:
            for b in lines:
                if b[j]=='1'and b in l:
                    l.remove(b)
    return l

def O2rating(lines):
    l=copy.deepcopy(lines)
    for j in range (0,12):
        c1=0
        c0=0
        for i in l:
            if i[j]=='1':
                c1+=1
            elif i[j]=='0':
                c0+=1
        if c1<c0:
            for b in lines:
                #print(l)
                if b[j]=='1' and len(l)>2 and b in l:
                        l.remove(b)
        elif c1>c0:
            for b in lines:
                #print(l)
                if b[j]=='0' and len(l)>2 and b in l:
                    l.remove(b)
        else:
            for b in lines:
                if b[j]=='0'and b in l:
                    l.remove(b)
    return l


O2rating=int(O2rating(lines)[0],2)
CO2rating=int(CO2rating(lines)[0],2)
print(O2rating*CO2rating)

    