# -*- coding: utf-8 -*-
"""
Created on Tue Dec 14 15:52:18 2021

@author: 91971
"""

import parse
f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D14.txt"

file=open(f1,'r')
lines=file.readlines()
polymer=lines[0][:-1]
rule1=[i[:-1] for i in lines[2:]]
print(polymer)
rules={}
element_count={}
pair_count={}

for i in polymer:
    if i in element_count:
        element_count[i]+=1
    else:
        element_count[i]=1

for i in rule1:
    formatstring='{} -> {}'
    parsed=parse.parse(formatstring,i)
    rules[parsed[0]]=parsed[1]
#print(rulesdict)

polylist=[polymer[j]+polymer[j+1] for j in range(0,len(polymer)-1)]
for i in polylist:
    if i in pair_count:
        pair_count[i]+=1
    else:
        pair_count[i]=1
    
    
for k in range(40):
    for pair,count in pair_count.copy().items():
        if rules[pair] in element_count:
            element_count[rules[pair]]+=count
        else:
            element_count[rules[pair]]=count
        pair_count[pair]-=count
        if pair[0]+rules[pair] in pair_count:
            pair_count[pair[0]+rules[pair]]+=count
        else:
            pair_count[pair[0]+rules[pair]]=count
        if rules[pair]+pair[1] in pair_count:
            pair_count[rules[pair]+pair[1]]+=count
        else:
            pair_count[rules[pair]+pair[1]]=count
    
    
    
print(max(element_count.values())-min(element_count.values()))
    
    
'''
#Function that makes the polymer
def MakePolymer(rulesdict,n):
    c=0
    while c!=n:
        global polymer
        duplicate=polymer
        polylist=[duplicate[j]+duplicate[j+1] for j in range(0,len(duplicate)-1)]
        print(len(polylist))
        polymer=duplicate[0]
        for i in polylist:
            polymer+=rulesdict[i]+i[-1]
        print(c)
        c+=1
    return

MakePolymer(rulesdict,40)

#find max instance
def maxchar(poly):
    checked=[]
    count=0
    for i in poly:
        if poly.count(i)>count and i not in checked:
            count=poly.count(i)
            checked.append(i)
        else:
            continue
    return count

#find min instance
def minchar(poly):
    checked=[]
    count=999999999999999999999
    for i in poly:
        if poly.count(i)<count and i not in checked:
            count=poly.count(i)
            checked.append(i)
        else:
            continue
    return count


print(maxchar(polymer)-minchar(polymer))



    '''