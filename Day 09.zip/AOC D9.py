# -*- coding: utf-8 -*-
"""
Created on Thu Dec  9 11:37:02 2021

@author: 91971
"""


f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D9.txt"

file=open(f1,'r')
lines=file.readlines()
lf=[i[:-1] for i in lines]
def findlowpoints(lines):
    l=[]
    location=[]
    for i in range(0,len(lines)):
        for j in range(0,len(lines[i])):
            temp=[]
            temp.append(lines[i][j])
            try:
                if j-1>=0:
                    temp.append(lines[i][j-1])
                else:
                    pass
            except:
                pass
            try:
                temp.append(lines[i][j+1])
            except:
                pass
            try:
                if i-1>=0:
                    temp.append(lines[i-1][j])
                else:
                    pass
            except:
                pass
            try:
                temp.append(lines[i+1][j])
            except:
                pass
            #print(temp)
            temp1=[int(i) for i in temp]
            if lowest(temp1,int(lines[i][j])):
                l.append(min(temp1))
                location.append([i,j])
    return (l,location)


def lowest(temp,x):
    if min(temp)==x and temp.count(x)==1:
        return True
    else:
        return False

    
a=findlowpoints(lf)[0]
ans=sum([i+1 for i in a])
print(ans)


def qn2(lines):
    loc=findlowpoints(lf)[1]
    '''
    for i in loc:
        tbc=[]
        checked=[]
        x=lines[i[0]][i[1]]
        tbc.append(lines[i[0]][i[1]])
        print(x)
        try:
            if lines[i[0]][i[1]+1]>x and lines[i[0]][i[1]+1]!='9':
                tbc.append(lines[i[0]][i[1]+1])
            else:
                pass
        except:
            pass
        try:
            if lines[i[0]][i[1]-1]>x and i[1]-1>=0 and lines[i[0]][i[1]-1]!='9':
                tbc.append(lines[i[0]][i[1]-1])
        except:
            pass
        try:
            if i[0]-1>=0 and lines[i[0]-1][i[1]]>x and lines[i[0]-1][i[1]]!='9':
                tbc.append(lines[i[0]-1][i[1]])
            else:
                pass
        except:
            pass
        try:
            if lines[i[0]+1][i[1]]>x and lines[i[0]+1][i[1]]!='9':
                tbc.append(lines[i[0]+1][i[1]])
        except:
            pass        
    '''

#tbc=[]
#checked=[]          
            
def basins(l1,lines):
    x=lines[l1[0]][l1[1]]
    global checked
    if l1 not in checked:
        try:
            if lines[l1[0]][l1[1]+1]>x and lines[l1[0]][l1[1]+1]!='9':
                #tbc.append([l1[0],l1[1]+1])
                basins([l1[0],l1[1]+1],lines)
        except:
            pass
        try:
            if lines[l1[0]][l1[1]-1]>x and l1[1]-1>=0 and lines[l1[0]][l1[1]-1]!='9':
                #tbc.append([l1[0],l1[1]-1])
                basins([l1[0],l1[1]-1],lines)
        except:
            pass
        try:
            if l1[0]-1>=0 and lines[l1[0]-1][l1[1]]>x and lines[l1[0]-1][l1[1]]!='9':
                #tbc.append([l1[0]-1,l1[1]])
                basins([l1[0]-1,l1[1]],lines)
        except:
            pass
        try:
            if lines[l1[0]+1][l1[1]]>x and lines[l1[0]+1][l1[1]]!='9':
                #tbc.append([l1[0]+1,l1[1]])
                basins([l1[0]+1,l1[1]],lines)
        except:
            pass
        checked.append(l1)
    return len(checked)

length=[]
for g in findlowpoints(lf)[1]:
    checked=[]
    length.append(basins(g,lines))   
    
length.sort()
print(length)

answer=length[-1]*length[-2]*length[-3]
print(answer)
         
                
                
                