# -*- coding: utf-8 -*-
"""
Created on Sun Dec  5 16:39:26 2021

@author: 91971
"""

import parse
f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D5.txt"

file=open(f1,'r')
a=file.readlines()
#print(a)
def parsing(a):
    for l in a:
        format_string='{},{} -> {},{}'
        parsed=parse.parse(format_string,l)
        print(parsed)
    return None



def segregate(lines):
    final=[]
    final2=[]
    for i in lines:
        format_string='{},{} -> {},{}'
        parsed=parse.parse(format_string,i)
        parsed=[int(parsed[0]),int(parsed[1]),int(parsed[2]),int(parsed[3])]
        if parsed[0]==parsed[2] or parsed[1]==parsed[3]:
            final.append(i[:-1])
        elif int((parsed[1] -parsed[3])/(parsed[0]-parsed[2]))==1 or int((parsed[1]-parsed[3])/(parsed[0]-parsed[2]))==-1:
            final2.append(i[:-1])
    return (final,final2)
    return final


#print(segregate(a))


def createMatrix():
    lf=[]
    for i in range(0,1000):
        l=[]
        for j in range (0,1000):
            l.append(0)
        lf.append(l)
    return lf

matrix=createMatrix()
#for horizontal and vertical lines
for u in segregate(a)[0]:
    format_string='{},{} -> {},{}'
    parsed=parse.parse(format_string,u)
    parsed=[int(parsed[0]),int(parsed[1]),int(parsed[2]),int(parsed[3])]
    #print(parsed)
    if parsed[0]==parsed[2]:
        if parsed[1]<parsed[3]:
            for k in range(parsed[1],parsed[3]+1):
                matrix[k][parsed[0]]+=1
            #print(matrix)
        else:
            for k in range(parsed[1],parsed[3]-1,-1):
                matrix[k][parsed[0]]+=1    
            #print(matrix)
    else:
        if parsed[0]<parsed[2]:
            for m in range(parsed[0],parsed[2]+1):
                matrix[parsed[1]][m]+=1
            #print(matrix)
        else:
            for m in range(parsed[0],parsed[2]-1,-1):
                matrix[parsed[1]][m]+=1
            #print(matrix)
                
#for inclined lines
#print(segregate(a)[1])
#print()
for z in segregate(a)[1]:
    format_string1='{},{} -> {},{}'
    parsed1=parse.parse(format_string1,z)
    parsed1=[int(parsed1[0]),int(parsed1[1]),int(parsed1[2]),int(parsed1[3])]
    m=int((parsed1[3]-parsed1[1])/(parsed1[2]-parsed1[0]))
    c=int(parsed1[1]-m*parsed1[0])
    if parsed1[0]<parsed1[2]:
        for t in range(parsed1[0],parsed1[2]+1):
            y=m*t+c
            matrix[y][t]+=1
    elif parsed1[0]>parsed1[2]:
        for q in range(parsed1[2],parsed1[0]+1):
            w=m*q+c
            matrix[w][q]+=1

c=0
for o in matrix:
    for p in o:
        if p>=2:
            c+=1
print(c)


               
