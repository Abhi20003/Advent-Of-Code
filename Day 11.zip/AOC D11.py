# -*- coding: utf-8 -*-
"""
Created on Sat Dec 11 13:53:46 2021

@author: 91971
"""
import copy

f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D11.txt"

file=open(f1,'r')
lines=[list(i[:-1]) for i in file.readlines()]



def flash(l,l0):#index of flash point
    
    for j in [-1,1,0]:
        for i in [-1,1,0]:
            try:
                if l0[l[0]+j][l[1]+i]!=0 and l0[l[0]+j][l[1]+i]!=9 and [i,j]!=[0,0] and l[0]+j>=0 and l[1]+i>=0:
                    l0[l[0]+j][l[1]+i]+=1
                elif l0[l[0]+j][l[1]+i]==9 and [i,j]!=[0,0] and l[0]+j>=0 and l[1]+i>=0:
                    l0[l[0]+j][l[1]+i]=0
                    flash([l[0]+j,l[1]+i],l0)
            except:
                pass
    return l0

sum1=0
l0=copy.deepcopy(lines)
l0=[[int(i) for i in j] for j in l0]
print(l0)
for u in range(800):
    for z in l0:
        for y in z:
            if y==0:
                continue
            else:
                break
        else:
            continue
        break
    else:
        print(u)
        break
    l0=[[j+1 if j!=9 else 0 for j in i] for i in l0]
    #print(l0[6][9])
    l2=[]
    for i in range(0,len(l0)):
        for j in range(0,len(l0[i])):
            if l0[i][j]==0:
                l2.append([i,j])
    if len(l2)!=0:
        for k in l2:
            lg=flash(k,l0)
        #print(lg[6][9])
        #print(lg)
        for i in range(0,len(lg)):
            for j in range(0,len(lg[i])):
                if lg[i][j]==0:
                    sum1+=1
    else:
        continue
print(sum1)
    



            



