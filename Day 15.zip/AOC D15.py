# -*- coding: utf-8 -*-
"""
Created on Wed Dec 15 13:04:22 2021

@author: 91971
"""
import copy

f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D15.txt"
f2=r"C:\Users\91971\OneDrive\Desktop\New Text Document (2).txt"
f3=r"C:\Users\91971\OneDrive\Desktop\New Text Document (3).txt"

file=open(f1,'r')
lines=file.readlines()
lf=[list(i[:-1]) for i in lines]
lf1=[[int(i) for i in j] for j in lf]
#print(lf1)

lf2=copy.deepcopy(lf1)
j=0
for i in lf2:
    i.extend([j+1 if j+1<=9 else j-8 for j in lf1[j]])
    i.extend([j+2 if j+2<=9 else j-7 for j in lf1[j]])
    i.extend([j+3 if j+3<=9 else j-6 for j in lf1[j]])
    i.extend([j+4 if j+4<=9 else j-5 for j in lf1[j]])
    j+=1


lf3=copy.deepcopy(lf2)


for q in range(1,5):
    for k in lf3:
        lf2.append([j+q if j+q<=9 else j+q-9 for j in k])

    
#print(len(lf2))
#for m in lf2:
   #print(m)

'''
for j in range(1,len(lf1)):
    sum1+=lf1[j][9]

for k in range(0,len(lf1)-1):
    sum2+=lf1[k][0]

if sum1>sum2:
    ref=sum2
else:
    ref=sum1
    '''
    
def CreateMatrix():
    SumfromStart=[]
    for i in range(len(lf2)):
        l1=[]
        for j in range(len(lf2)):
            l1.append(999999999999)
        SumfromStart.append(l1)
    return SumfromStart

SumMatrix=CreateMatrix()
#print(SumMatrix)
    
def traversal():
    z=0
    FinalPath=[]
    PossiblePath=[['0','0',0]]
    while PossiblePath!=[]:
        #print(z)
        temp=PossiblePath.pop(0)
        row=int(temp[0])
        col=int(temp[1])
        sum3=temp[2]
        if sum3>=SumMatrix[row][col]:
            print("Skip this path",row,col)
            continue
        else:
            SumMatrix[row][col]=sum3
            
        if row==len(lf2)-1 and col==len(lf2)-1:
            FinalPath.append(temp)
            print('Final Path Reached')
            continue
        
        if row<len(lf2)-1:
            temp1=[str(row+1),str(col),sum3+lf2[row+1][col]]
            PossiblePath.append(temp1)
        if col<len(lf2)-1:
            temp2=[str(row),str(col+1),sum3+lf2[row][col+1]]
            PossiblePath.append(temp2)
            
        print("Length of PossiblePath", len(PossiblePath))
                

        z+=1
    return SumMatrix[len(lf2)-1][len(lf2)-1]

print(traversal())

        