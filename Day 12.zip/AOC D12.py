# -*- coding: utf-8 -*-
"""
Created on Sun Dec 12 13:11:38 2021

@author: 91971
"""

import parse
f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D12.txt"

file=open(f1,'r')
lines=file.readlines()

#create dictionary function
d={}
def Createdict():
    format_string='{}-{}'
    for i in lines:
        parsed=parse.parse(format_string,i)
        if parsed[0] in d.keys():
            d[parsed[0]].append(parsed[1][:-1])
        if parsed[1][:-1] in d.keys() :
            d[parsed[1][:-1]].append(parsed[0])           
        if parsed[0] not in d.keys():
            d[parsed[0]]=[parsed[1][:-1]]
        if parsed[1][:-1] not in d.keys() :
            d[parsed[1][:-1]]=[parsed[0]]
    return d

dict1 = Createdict()
print(dict1)


def Traverse():
    PossibleRoutes=[['No2Scave','start']]
    FinalRoute=[]
    while PossibleRoutes!=[]:
        temp=PossibleRoutes.pop(0)
        #for i in dict1[temp]:
            #a=temp[:-1]
        for i in dict1[temp[-1]]:
            if i.islower() and i in temp:
                if temp[0]=='2Scave' or i=='start':
                    pass
                else:
                    templist=temp+[i]
                    templist[0]='2Scave'
                    PossibleRoutes.append(templist)
            else:
                templist=temp+[i]
                if i=='end':
                    FinalRoute.append(templist)
                else:   
                    PossibleRoutes.append(templist)
                
        #print(PossibleRoutes)
    return FinalRoute
            
for i in Traverse():
    print(i)
#print(Traverse())
print(len(Traverse()))