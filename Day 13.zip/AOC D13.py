# -*- coding: utf-8 -*-
"""
Created on Mon Dec 13 14:17:00 2021

@author: 91971
"""

import parse
f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D13.txt"

file=open(f1,'r')
lines=file.readlines()
lf1=[i[:-1].split(',') for i in lines[:lines.index('\n')]]
lf2=[[int(i) for i in j] for j in lf1]
folds=[i[:-1] for i in lines[lines.index('\n')+1:]]
#print(lf2)
#print(folds)

def CreateMatrix(n):
    l2=[]
    for i in range(n):
        l1=[]
        for j in range(n):
            l1.append(' ')
        l2.append(l1)
    return l2

l2=CreateMatrix(1400)
 
def Mark(lf2,l2):
    for i in lf2:
        l2[i[1]][i[0]]='#'
    return l2

markedlist=Mark(lf2,l2)

def folding(folds,markedlist):
    for i in folds:
        formatstring = 'fold along {}={}'
        parsed=parse.parse(formatstring,i)
        parsed=[parsed[0],int(parsed[1])]
        if parsed[0]=='y':
            #for j in range(len(markedlist[parsed[1]])):
                #markedlist[parsed[1]][j]='-'
            for k in range(parsed[1],len(markedlist)):
                for m in range(len(markedlist[k])):
                    if markedlist[k][m]=='#':
                        markedlist[2*parsed[1]-k][m]='#'  
            while markedlist[-1]!=markedlist[parsed[1]]:
                markedlist.pop()
            markedlist.pop()
        elif parsed[0]=='x':
            #for i in markedlist:
                #i[parsed[1]]='-'
            for k in range(parsed[1],len(markedlist[0])):
                for m in range(len(markedlist)):
                    if markedlist[m][k]=='#':
                        markedlist[m][2*parsed[1]-k]='#'
            for z in markedlist:
                for q in range(len(z)+1-parsed[1]):
                    z.pop()
    return markedlist
        
markedlist = folding(folds,markedlist)


def CountMarks(markedlist):
    c=0
    for i in markedlist:
        for j in i:
            if j=='#':
                c+=1
    return c

print(CountMarks(markedlist))

for i in markedlist:
    print(i)