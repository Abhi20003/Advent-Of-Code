# -*- coding: utf-8 -*-
"""
Created on Fri Dec 10 10:34:42 2021

@author: 91971
"""


f1=r"C:\Users\91971\OneDrive\Desktop\AOC\Inputs\input_D10.txt"

file=open(f1,'r')
lines=[i[:-1] for i in file.readlines()]


d={
   '<':'>',
   '{':'}',
   '(':')',
   '[':']',
   '0':1
   }

points1={
        ')': 3,
        ']': 57,
        '}': 1197,
        '>': 25137
        }
points2={
        ')': 1,
        ']': 2,
        '}': 3,
        '>': 4
        }

def pop(stack):
    if len(stack)!=0:
        element=stack.pop()
        return element
    else:
        print('Underflow')
        return False

def push(x,stack):
    stack.append(x)
    
def top(stack):
    if len(stack)!=0:
        element=stack[-1]
        return element
    else:
        return '0'
    
def first(stack):
    if len(stack)!=0:
        element=stack[0]
        return element
    else:
        return '0'
    
def popfirst(stack):
    if len(stack)!=0:
        element=stack.pop(0)
        return element
    else:
        print('Underflow')
        return False
    
    
        
score1=0
lscore=[]

for i in lines:
    stack=[]
    try:
        for j in i:
            score2=0
            top1=top(stack)
            if d[top1]!=j: 
                push(j,stack)
                #print(stack)
            else:
                pop(stack)
                #print(stack)
        if len(stack)==0:
            '''print("yes")'''

        else:
            for i in stack:
                if i in d.keys():
                    continue
            else:
                for k in range(0,len(stack)):
                    top2=d[top(stack)]
                    score2=(score2*5)+points2[top2]
                    #print(score2)
                    #print(stack)
                    pop(stack)
                #print("Incomplete")
                #print(score2)
                lscore.append(score2)
    except:
        illegal=top1
        score1+=points1[top1]
        #print("Corrupt")
        
#print(score1)
lscore.sort()
print(lscore[int((len(lscore)-1)/2)])

            
